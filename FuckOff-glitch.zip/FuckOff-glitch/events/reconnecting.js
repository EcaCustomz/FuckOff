module.exports = client => { // eslint-disable-line no-unused-vars
  console.log(`Reconnecting at ${new Date()}`);
};
