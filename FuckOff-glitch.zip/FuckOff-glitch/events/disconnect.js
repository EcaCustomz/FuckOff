module.exports = client => { // eslint-disable-line no-unused-vars
  console.log(`You have been disconnected at ${new Date()}`);
};
