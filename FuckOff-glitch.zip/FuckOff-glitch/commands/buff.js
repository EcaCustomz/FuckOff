exports.run = (client, message) => {
message.channel.send(`http://i0.kym-cdn.com/photos/images/newsfeed/001/310/724/709.png`);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'buff',
  description: 'She be SWOLL',
  usage: 'buff'
};
