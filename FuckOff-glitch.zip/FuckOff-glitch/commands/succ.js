exports.run = (client, message) => {
message.channel.send(`https://images.axios.com/0oKXSKlQFprBqjFDpA-iDywDwFo=/1080x1080/smart/2017/12/15/1513306374047.gif`);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'succ',
  description: 'He got the SUCC',
  usage: 'succ'
};
