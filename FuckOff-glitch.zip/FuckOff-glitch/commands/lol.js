exports.run = (client, message) => {
message.channel.send(`http://i0.kym-cdn.com/photos/images/newsfeed/001/293/670/b7d.jpg`);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'lol',
  description: 'crying',
  usage: 'lol'
};
