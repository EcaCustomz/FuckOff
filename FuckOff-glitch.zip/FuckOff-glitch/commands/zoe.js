exports.run = (client, message) => {
  message.channel.send('._.')
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'zoe',
  description: 'Kay.....Zoe',
  usage: 'zoe'
};
